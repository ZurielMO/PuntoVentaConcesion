<?php
// Fallback si DirectoryIndex no incluye index.html.
readfile(__DIR__ . '/index.html');
